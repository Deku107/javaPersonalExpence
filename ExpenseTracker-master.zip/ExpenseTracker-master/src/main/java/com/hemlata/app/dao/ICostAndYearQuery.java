package com.hemlata.app.dao;

public interface ICostAndYearQuery {
	public Integer getCost();
	public String getYear();
}
